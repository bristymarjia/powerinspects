<?php
    $username = $_POST['username'];
    $password = $_POST['password'];
    $connection = new mysqli("localhost", "pickjgha_cse", "6zg0baOZZqRR", 'pickjgha_cse385');
    $result = mysqli_query($connection, "SELECT * FROM tbl_user WHERE username = '$username' AND password = '$password' LIMIT 1");
    $data = $result->fetch_row();
    echo $data;
    header("Location: https://powerinspects.com");