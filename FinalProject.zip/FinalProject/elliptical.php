<?php include('./includes/header.php'); ?>
<h1 style="color: white; text-align:center; margin-top:20px"> Top Elliptical Machines </h1>
<!-- 1st image row start here -->

<div class="container" style="margin-top:20px">
    <div class="row justify-content-md-center">
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e1.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Circle Fitness Elliptical </h5>
                    <p class="card-text">The exclusive Circle Fitness M8E Elliptical is designed for hotels, resorts,
                        multi-family housing, corporations, police and fire departments, school, health clubs. </p>
                    <a href="buy.php?name=Circle+Fitness+Elliptical" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e2.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">T101 Elliptical</h5>
                    <p class="card-text">Hit the ground running with quick and easy setup in 30 minutes or fewer.
                        Intuitive controls for no-nonsense workouts. So, get this one. </p>
                    <a href="buy.php?name=T101+Elliptical" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e3.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Exo 2 Elliptical</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the
                        card's content. 2-year parts warranty, and 1-year labor warranty.</p>
                    <a href="buy.php?name=EXO+2+Elliptical" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>

        <!-- 1st image row end here -->

        <!-- 2nd image row start here -->
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e4.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">PRECOR TRM 223 Elliptical</h5>
                    <p class="card-text">The exclusive Circle Fitness M7E Elliptical is designed for hotels, resorts,
                        multi-family housing, corporations, police and fire departments, school, health clubs and of
                        course homes.</p>
                    <a href="buy.php" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e5.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Circle Fitness M7E</h5>
                    <p class="card-text">Looking for fitness equipment that feels great, is reliable, lasts for years.
                    </p>
                    <a href="buy.php" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e6.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">TUNTURI Elliptical FITRUN 70I</h5>
                    <p class="card-text">How do you maintain your fitness level? By walking – anywhere from brisk
                        walking to sprinting – you work on your stamina, you become fitter and you burn calories. So,
                        get this one. </p>
                    <a href="buy.php" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>

        <!-- 2nd image row end here -->

        <!-- 3rd image row start here -->
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e7.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">NordicTrack T Series Elliptical</h5>
                    <p class="card-text">Bring Home Interactive Personal Training powered by iFit; 1-year iFit family
                        membership included; create up to 5 individual exercise profiles</p>
                    <a href="buy.php" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e8.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">ProForm - 505 CST Elliptical</h5>
                    <p class="card-text">The T5 Elliptical allows you to train on three different running surface
                        firmness settings thanks to the FlexDeck Select system. So, buy this one. </p>
                    <a href="buy.php" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <img class="card-img-top" src="img/e9.jpg" alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Viva T-755 Motorized Elliptical</h5>
                    <p class="card-text">J K Gaur Fitness - Offering Viva T-755 Motorized Elliptical, for Gym, 18" X 55"
                        at Rs 90000/unit in Jodhpur, Rajasthan. </p>
                    <a href="buy.php" class="btn btn-danger">Buy Now</a>
                </div>
            </div>
        </div>
        <!-- 3rd image row end here -->
    </div>
</div> -->

<?php include('./includes/footer.php'); ?>