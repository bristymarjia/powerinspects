<?php include('./includes/header.php'); ?>


<div class="container" style="height: calc(100vh - 204px);">
    <div class="h-100 row justify-content-md-center align-items-center">
        <div class="col-lg-6 col-sm-12">
            <div class="m-3 p-3 bg-white rounded">
                <h4 class="mb-2 text-center">Ordering <strong><?php echo $_GET['name']; ?></strong></h4>
                <form class="m-2" method="POST" action="./handle-buy.php">
                    <div class="form-group">
                        <form>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="inputEmail4">Phone Number *</label>
                                    <input type="text" name="mobile" class="form-control" id="inputEmail4"
                                        placeholder="Phone Number" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputPassword4">Email</label>
                                    <input type="email" name="email" class="form-control" id="inputPassword4"
                                        placeholder="Email (optional)">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputAddress">Address L1 *</label>
                                <input type="text" name="address_1" class="form-control" id="inputAddress"
                                    placeholder="1234 Main St" required>
                            </div>
                            <div class="form-group">
                                <label for="inputAddress2">Address L2</label>
                                <input type="text" name="address_2" class="form-control" id="inputAddress2"
                                    placeholder="Apartment, studio, or floor">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="inputCity">Credit Card Number *</label>
                                    <input type="text" name="card" class="form-control" id="inputCity" required>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="inputState">Expiry *</label>
                                    <select id="inputState" name="expiry" class="form-control" required>
                                        <option selected>Choose...</option>
                                        <?php for ($i = 2021; $i < 2030; $i++) { ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="inputDate">CVC *</label>
                                    <input type="text" name="cvc" class="form-control" id="inputZip" required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-danger">Confirm</button>
                        </form>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include('./includes/footer.php'); ?>