<?php
$username = $_POST['username'];
$fullname = $_POST['fullname'];
$byear = $_POST['byear'];
$bmonth = $_POST['bmonth'];
$bday = $_POST['bday'];
$gender = $_POST['gender'];
$password = $_POST['password'];
$password_confirmation = $_POST['password_confirmation'];
$email = $_POST['email'];
$package = $_POST['package'];
if($password != $password_confirmation) {
    echo "Paswords dont match!";
    die();
}

$connection = new mysqli("localhost:3306", "pickjgha_cse", "6zg0baOZZqRR", 'pickjgha_cse385');

mysqli_query($connection, "INSERT INTO tbl_user(username, fullname, byear, bmonth, bday, gender, password, email, package)
VALUES('$username', '$fullname', '$byear', '$bmonth', '$bday', '$gender', '$password', '$email', '$package');");

header("Location: https://powerinspects.com/login.php");