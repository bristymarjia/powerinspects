<?php include('./includes/header.php'); ?>


<h1 style="color: white; text-align:center; margin-top:20px"> Our Packages </h1>
<div class="container" style="margin-top:20px">
    <div class="row justify-content-md-center">

        <!-- 1st image row start here -->
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/p1.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Bronze</h5>
                        <p class="card-text">Our pre-designed Bronze package have been created by our Pro Gym Supply
                            specialist and the carefully selected strength and cardio equipment will serve a wide
                            variety of clientele. Opening your own studio is the beginning of building.
                        </p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Star Trac E-UB Upright Bike x 1</li>
                        <li class="list-group-item">Precor 615 Upright Bike x 1</li>
                        <li class="list-group-item">Ocatne Pro 3700 Total Body Elliptical x 1 500 lbs</li>
                        <li class="list-group-item">Price: $19.99/mo</li>
                    </ul>
                    <div class="card-body">
                        <a href="buy.php" class="btn btn-danger">Purchase Now</a>
                    </div>
                </div>

            </div>
        </div>

        <!-- 1st image row end here -->

        <!-- 2nd image row start here -->
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/p2.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Silver</h5>
                        <p class="card-text">Our pre-designed Silver packages have been created by our Pro Gym Supply
                            specialist and the carefully selected strength and cardio equipment will serve a wide
                            variety of clientele. Opening your own studio is the beginning of building.
                        </p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Commercial Smith Machine x 1</li>
                        <li class="list-group-item">Cybex 630AT Arc Trainer x 1
                        </li>
                        <li class="list-group-item">Cap Barbell Rubber Olympic Grip Plates (600 lbs Set) x 1</li>
                        <li class="list-group-item">Price: $26.99/mo</li>
                    </ul>
                    <div class="card-body">
                        <a href="buy.php" class="btn btn-danger">Purchase Now</a>
                    </div>
                </div>

            </div>
        </div>


        <!-- 2nd image row end here -->

        <!-- 3rd image row start here -->
        <div class="col-md-4 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/p3.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Gold</h5>
                        <p class="card-text">Our pre-designed gold packages have been created by our Pro Gym Supply
                            specialist and the carefully selected strength and cardio equipment will serve a wide
                            variety of clientele. Opening your own studio is the beginning of building your own dream.
                        </p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Star Trac E-TRX Treadmills x 1
                        </li>
                        <li class="list-group-item">FreeMotion Functional Trainer x 1
                        </li>
                        <li class="list-group-item">Cap Barbell RK-31 Stadium Rack (3 Tier: Holds 15 Pairs) x 1
                        </li>
                        <li class="list-group-item">Price: $36.99/mo</li>
                    </ul>
                    <div class="card-body">
                        <a href="buy.php" class="btn btn-danger">Purchase Now</a>
                    </div>
                </div>

            </div>
        </div>

        <!-- 3rd image row end here -->

    </div>
</div>
<?php include('./includes/footer.php'); ?>