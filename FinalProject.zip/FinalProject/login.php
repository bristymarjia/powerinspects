<?php include('./includes/header.php'); ?>

<div class="container" style="height: calc(100vh - 204px);">
    <div class="h-100 row justify-content-md-center align-items-center">
        <div class="col-lg-6 col-sm-12">
            <h1 class="text-white text-center">Login</h1>
            <div class="m-3 p-3 bg-white rounded">
                <form class="m-2" method="POST" action="./handle-login.php">
                    <div class="form-group">
                        <label class="form-label" for="username">Username</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-username"><i class="far fa-user"></i></span>
                            </div>
                            <input type="text" placeholder="Username" value="" name="username" id="username"
                                class="form-control" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-password"><i
                                        class="fas fa-shield-alt"></i></span>
                            </div>
                            <input type="password" placeholder="Password" value="" name="password" id="password"
                                class="form-control" />
                        </div>
                    </div>
                    <p class="m-0 text-center">
                        <button class="btn btn-danger w-50" type="submit">Sign In</button>
                    </p>
                </form>
                <p class="text-center">or</p>
                <p class="m-0 text-center">

                    <a href="./join.php" class="btn w-50 btn-info" type="submit">Join Us</a>
                </p>

            </div>
        </div>
    </div>
</div>
<?php include('./includes/footer.php'); ?>