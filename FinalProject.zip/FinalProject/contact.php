<?php include('./includes/header.php'); ?>

<section id="get-in-touch-heading" class="py-5">
    <div class="overlay"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col text-center py-5 text-white">
                <h1 class="text-capitalize">get in touch</h1>
                <p>Close to Work. Commit to be fit. Dare to be great. Don't be a brat, burn that fat.
                </p>
            </div>
        </div>
    </div>
</section>
<section id="get-in-touch-content" class="py-5">
    <div class="container">
        <div class="row d-flex align-items-start">
            <div class="col-7">
                <h3 class="">Other ways to connect</h3>
                <p>Call, email, send us postcard - whatever works for you. We'll be here</p>
                <div class="d-flex align-items-center py-2 border-bottom border-primary">
                    <div
                        class="rounded-circle bg-primary contact-icons d-flex justify-content-center align-items-center mr-2">
                        <i class="fas fa-headset text-light"></i>
                    </div>
                    +8801111111111
                </div>
                <div class="d-flex align-items-center py-2 border-bottom border-primary">
                    <div
                        class="rounded-circle bg-primary contact-icons d-flex justify-content-center align-items-center mr-2">
                        <i class="fas fa-envelope text-light"></i>
                    </div>
                    mformarjia@gmail.com
                </div>
                <div class="d-flex align-items-center py-2">
                    <div
                        class="rounded-circle bg-primary contact-icons d-flex justify-content-center align-items-center mr-2">
                        <i class="fas fa-map-marker-alt text-light"></i>
                    </div>
                    123 Street, ABC City, XYZ State, 12345, Country
                </div>
            </div>
            <div class="col-5">
                <div class="shadow p-4 rounded">
                    <h2>Contact With Power Inspect</h2>
                    <form action="#" method="POST">
                        <div class="form-group">
                            <label for="first-name">Name</label>
                            <input type="text" class="form-control" id="first-name" name="first-name">
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>

                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea rows="7" class="form-control" id="message" name="message"></textarea>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">Send</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</section>



<?php include('./includes/footer.php'); ?>