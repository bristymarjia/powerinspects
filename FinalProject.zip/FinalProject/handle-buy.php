<?php

$email = $_POST['email'];
$card = $_POST['card'];
$mobile = $_POST['mobile'];
$addres_1 = $_POST['address_1'];
$addres_2 = $_POST['address_2'];
$expiry = $_POST['expiry'];
$cvc = $_POST['cvc'];

$connection = new mysqli("localhost", "pickjgha_cse", "6zg0baOZZqRR", 'pickjgha_cse385');

mysqli_query($connection, "INSERT INTO tbl_order(mobile, email, address_1, address_2, card, expiry, cvc)
VALUES('$mobile', '$email', '$address_1', '$address_2', '$card', '$expiry', '$cvc');");

echo 'Ordered successfully!';