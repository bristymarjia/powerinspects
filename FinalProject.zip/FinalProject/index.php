<?php include('./includes/header.php'); ?>
<!-- body Background Image Start-->
<div id="carouBar" class="carousel slide hero" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouBar" data-slide-to="0" class="active"></li>
        <li data-target="#carouBar" data-slide-to="1"></li>
        <li data-target="#carouBar" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="d-block w-100" src="img/bgimg1.jpg" alt="Gym BG IMAGE 1">
            <div class="carousel-caption">
                <h5 class="fs-lg-4">If you want to be a hit in life, you gotta be fit and fine</h5>
                <a href="join.php" class="btn btn-lg btn-danger rounded-pill d-none d-lg-inline-block">Join As
                    Member</a>
            </div>
        </div>

        <div class="carousel-item">
            <img class="d-block w-100" src="img/bgimg2.jpg" alt="Gym BG IMAGE 2">
            <div class="carousel-caption">
                <h5>Rest a while and run a mile.</h5>
                <a href="membership.php" class="btn btn-lg btn-danger rounded-pill d-none d-lg-inline-block">Membership
                    Packages</a>
            </div>
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="img/bgimg3.jpg" alt="Gym BG IMAGE 3">
            <div class="carousel-caption">
                <h5>Exercise your mind and body.</h5>
                <a href="about.php" class="btn btn-lg btn-danger rounded-pill d-none d-lg-inline-block">About Us</a>
            </div>
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouBar" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouBar" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- body Background Image end -->


<!-- body blog part start-->

<!-- body blog part end -->

<!-- ^^^ temp line -->
<?php include('./includes/footer.php'); ?>