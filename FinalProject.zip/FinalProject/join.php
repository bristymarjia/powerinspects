<?php include('./includes/header.php'); ?>

<div class="container">
    <div class="row justify-content-md-center">
        <div class="col-lg-6 col-sm-12 mt-3">
            <h1 class="text-white text-center">Create an Account</h1>
            <div class="m-3 p-3 bg-white rounded">
                <form class="m-2" method="POST" action="./handle-join.php">
                    <div class="form-group">
                        <label class="form-label" for="username">Username</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-username"><i class="far fa-user"></i></span>
                            </div>
                            <input type="text" placeholder="Username" value="" name="username" id="username"
                                class="form-control" />
                            <p class="small">Username must be a non-spaced, alphanumeric word, supposedly your nickname.
                                Any non-letter symbols will be removed automatically.</p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="fname">Full Name</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-email"><i class="far fa-user-plus"></i></span>
                            </div>
                            <input type="text" placeholder="Full name" value="" name="fullname" id="fname"
                                class="form-control" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="email">Email</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-email"><i class="far fa-envelope"></i></span>
                            </div>
                            <input type="text" placeholder="Enter email" value="" name="email" id="email"
                                class="form-control" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-password"><i
                                        class="fas fa-shield-alt"></i></span>
                            </div>
                            <input type="password" placeholder="Password" value="" name="password" id="password"
                                class="form-control" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="confirm_password">Confirm Password</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-confPassword"><i
                                        class="fas fa-history"></i></span>
                            </div>
                            <input type="password" placeholder="Re-enter password" value="" name="password_confirmation"
                                id="confirm_password" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Birthdate</label>
                        <div class="mb-1 input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-confPassword"><i
                                        class="fas fa-birthday-cake"></i></span>
                            </div>
                            <select name="bmonth" value="" class="form-control">
                                <option value="">Month... </option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                            <select name="bday" value="" class="form-control">
                                <option value="">Day... </option>
                                <?php for ($i = 1; $i <= 31; $i++) { ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php } ?>
                            </select>
                            <select name="byear" value="" class="form-control">
                                <option value="">Year... </option>
                                <?php for($i = 2020; $i >= 1971; $i--) { ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Gender</label>
                        <div class="mb-1 input-group">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" name="gender" value="1" id="gender-male"
                                    class="custom-control-input" />
                                <label title="" for="gender-male" class="custom-control-label">Male</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" name="gender" value="2" id="gender-female"
                                    class="custom-control-input" />
                                <label title="" for="gender-female" class="custom-control-label">Female</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" name="gender" value="3" id="gender-other"
                                    class="custom-control-input" />
                                <label title="" for="gender-other" class="custom-control-label">Other</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Packages</label>
                        <div class="mb-1 input-group d-flex flex-column">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" name="package" value="1" id="package-gold"
                                    class="custom-control-input" />
                                <label title="" for="package-gold" class="custom-control-label">Gold
                                    <strong
                                        style="text-decoration:underline;color:#666;margin-left:10px;margin-bottom:10px;">($36.99/mo)</strong></label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" name="package" value="2" id="package-silver"
                                    class="custom-control-input" />
                                <label title="" for="package-silver" class="custom-control-label">Silver
                                    <strong
                                        style="text-decoration:underline;color:#666;margin-left:10px;margin-bottom:10px;">($26.99/mo)</strong>
                                </label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" name="package" value="3" id="package-bronze"
                                    class="custom-control-input" />
                                <label title="" for="package-bronze" class="custom-control-label">Bronze
                                    <strong
                                        style="text-decoration:underline;color:#666;margin-left:10px;margin-bottom:10px;">($19.99/mo)</strong>
                                </label>

                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="custom-control custom-checkbox custom-control-inline">
                            <input type="checkbox" name="tos" id="tnc" class="custom-control-input" />
                            <label for="tnc" class="custom-control-label">I accept the <a href="#">T&amp;C</a></label>
                        </div>
                    </div>
                    <p class="m-0 text-center">
                        <button class="btn btn-danger w-50" type="submit">Sign Up</button>
                    </p>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include('./includes/footer.php'); ?>