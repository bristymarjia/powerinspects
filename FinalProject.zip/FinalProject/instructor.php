<?php include('./includes/header.php'); ?>

<div class="card bg-dark text-white hero">
    <img class="card-img" src="img/g1.jpg" alt="Card image">
    <div class="card-img-overlay">
        <h3 class="card-title">Push harder today if you want a different tomorrow!</h3>
    </div>
</div>
<h1 style="color: white; text-align:center; margin-top:20px"> Our Gym Instructors </h1>
<div class="container" style="margin-top:20px">
    <div class="row justify-content-md-center">


        <!-- 1st image row start here -->
        <div class="col-md-6 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/i1.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Mike O’Halloran</h5>
                        <p class="card-text">Don’t get confused, even if you’re more of an introvert, that doesn’t mean
                            you can’t be a good communicator – these two characteristics are not mutually.

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- 1st image row end here -->

        <!-- 2nd image row start here -->

        <div class="col-md-6 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/i2.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Katlyn Burris</h5>
                        <p class="card-text">It’s not enough to be interested in fitness or to just enjoy your own
                            training, if you want to be a good.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2nd image row end here -->

        <!-- 3rd image row start here -->
        <div class="col-md-6 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/i3.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Paul</h5>
                        <p class="card-text">That way, you can work with them and make the necessary changes. Otherwise,
                            they will become demotivated, stop seeing the benefits of training, and eventually give up
                            on their training. </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- 3rd image row end here -->

        <!-- 4th image row start here -->
        <div class="col-md-6 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/i4.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Marcus</h5>
                        <p class="card-text">Being punctual is also important when it comes to sticking to your
                            schedule, some days you’ll be back to back training clients. Make your life hit staying fit.
                            Also, eat healthy!
                            So, enhance the beauty of life being fit and healthy.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- 4th image row end here -->

        <!-- 5th image row start here -->
        <div class="col-md-6 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/i5.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Jack</h5>
                        <p class="card-text">Even outside of being self-employed, working for a gym requires a great
                            deal of organisation and time management.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-12">
            <div class="card my-2">
                <div class="card">
                    <img class="card-img-top" src="img/i6.jpg" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">John</h5>
                        <p class="card-text">If you enjoy your job, you’ll find yourself naturally putting more effort
                            into your work, and going above and beyond for your clients.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- 5th image row end here -->
    </div>
</div>

<?php include('./includes/footer.php'); ?>