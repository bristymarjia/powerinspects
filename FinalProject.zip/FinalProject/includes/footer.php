<footer class="d-flex flex-column flex-md-row justify-content-between align-items-center bg-dark text-white footerbar">
    <div class="navbar-brand py-2 px-3" href="#">
        Be Fit, Be Yourself!
    </div>
    <ul class="d-flex flex-row list-unstyled mb-0">
        <li class="mx-2"><a class="text-white" href="https://www.facebook.com/marjiapro/"> <i
                    class="fab fa-facebook"></i></a> </li>
        <li class="mx-2"><a class="text-white" href="https://twitter.com/bristymarjia"><i
                    class="fab fa-twitter"></i></a></li>
        <li class="mx-2"><a class="text-white" href="https://www.instagram.com/bristymarjia/"> <i
                    class="fab fa-instagram"></i></a></li>
        <li class="mx-2"><a class="text-white" href="https://www.linkedin.com/in/bristymarjia/"><i
                    class="fab fa-linkedin"></i></a></li>
    </ul>
    <div class="d-flex">
        <div class="nav-item">
            <a class="nav-link mr-2" href="./about.php">About Us</a>
        </div>

        <div class="nav-item">
            <a class="nav-link mr-md-3" href="./contact.php">Contact Us</a>
        </div>
    </div>
</footer>
</body>

</html>