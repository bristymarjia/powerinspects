<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Power Inspect</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>


</head>

<body>
    <!-- Start Logo & Seacrh  -->
    <div class="fixed-top">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center topbar pb-2">
            <img id="logo" src="img/logo1.png" alt="Logo">
            <form class="form-inline my-2 my-lg-0 mr-3">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
        </div>
        <!-- End Logo & Search  -->

        <!-- Menu Start -->
        <nav class="navbar navbar-expand-lg navbar-dark secondary-bar p-0">
            <a class="navbar-brand py-2 px-3" href="./">
                Home
            </a>
            <button class="navbar-toggler mr-1" type="button" data-toggle="collapse" data-target="#menu-toggle"
                aria-controls="menu-toggle" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="menu-toggle">
                <ul class="navbar-nav ml-auto mr-2">
                    <li class="nav-item">
                        <a class="nav-link" href="membership.php">Get Membership</a>
                    </li>
                    <li class="nav-item dropdown">


                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Equipment
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="treadmill.php">Treadmill</a>
                            <a class="dropdown-item" href="elliptical.php">Elliptical</a>
                            <a class="dropdown-item" href="rowing.php">Rowing Machine</a>
                            <a class="dropdown-item" href="bike.php"> Excercise Bike</a>

                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="index.php">More</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="instructor.php">Instructors</a>
                    </li>
                    <li class="nav-item bg-danger rounded mx-2">
                        <a class="nav-link" href="./login.php">
                            <span class="text-white">Log In</span>
                        </a>
                    </li>
                    <li class="nav-item bg-info rounded">
                        <a class="nav-link" href="./join.php">
                            <span class="text-white">Join</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <!-- Menu End -->