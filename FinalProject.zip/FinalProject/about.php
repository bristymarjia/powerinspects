<?php include('./includes/header.php'); ?>

<section id="who-we-are-heading" class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-5 offset-1 p-5">
                <div class="top-line"></div>
                <h1 class="text-uppercase mt-3">who we are</h1>
            </div>
            <div class="col-5 offset-1 d-flex align-items-end">
                <p class="text-justify">Power Inspect provides a 24/7 Fitness facility to residents of Martinsville and
                    Henry
                    County, as well as surrounding areas to help people reach and maintain their goals. We combine
                    different types of fitness equipment to meet different fitness needs and levels. </p>
            </div>
        </div>
    </div>
</section>
<section class="mt-5 py-5" id="who-we-are-content">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-6">
                <img src="img/m.jpg" alt="Queen" class="img-fluid" id="q-img">
            </div>
            <div class="col-5 offset-1">
                <h2 class="text-uppercase">our people come first</h2>
                <p class="mt-5">At Power Inspect you’ll find all the latest strength and cardio equipment along with a
                    energetic group exercise program that includes POUND, Zumba, Kickboxing, Bootcamp, Muscle Building
                    and many other cardio classes. You’ll find a supportive environment with all kinds of people who are
                    working just as hard as you to meet their goals.
                </p>
                <p class="mt-5">
                    Our Staff, Trainers & Group exercise instructors are committed to offering our members a great
                    fitness experience. Whether you’re a mom looking to get back into shape, a marathon runner trying to
                    shave a few minutes off your personal best or just trying to stay healthy we would love to help you
                    realize your potential and meet your goals!!</p>
            </div>
        </div>
    </div>
</section>





<?php include('./includes/footer.php'); ?>